$( function() {
    $("embed").wrap("<div class='video-container [vimeo, widescreen]'></div>");
    $("iframe").wrap("<div class='video-container [vimeo, widescreen]'></div>");
});