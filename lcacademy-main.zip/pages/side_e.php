<div class="aside_snb">
    <p class="title"><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=notice">고객서비스</a></p>
    <ul>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=counseling">생애설계(진로)상담</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=coach">교육(코칭)신청</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=qna">Q&amp;A</a></li>
        <li><a href="menu_e_5.php">오시는 길</a></li>    
    </ul>
</div>