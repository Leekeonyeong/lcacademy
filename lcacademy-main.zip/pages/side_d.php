
<div class="aside_snb">
    <p class="title"><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=arialchan">커뮤니티</a></p>
    <ul>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=arialchan">아리알찬</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=skyrone">스카이론</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=bungbung">마을여행</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=appcoding">앱코딩</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=youtube">유튜브</a></li>    
    </ul>
</div>