
<div class="aside_snb">
    <p class="title"><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=project_ing">프로젝트</a></p>
    <ul>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=project_ing">진행중인 프로젝트</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=project_end">종료된 프로젝트</a></li>
        <!-- <li><a href="menu_c_3.php">사업분야</a></li> -->
    </ul>
</div>