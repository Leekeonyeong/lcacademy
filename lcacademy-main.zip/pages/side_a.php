<div class="aside_snb">
    <p class="title"><a href="menu_a.php">조합소개</a></p>
    <ul>
        <li><a href="menu_a_1.php">핵심가치/미션/비전</a></li>
        <!-- <li><a href="menu_a_2.php">연혁</a></li> -->
        <li><a href="menu_a_3.php">사업분야</a></li>
        <li><a href="menu_a_4.php">운영진 소개</a></li>
        <li><a href="menu_a_5.php">강사진 소개</a></li>    
    </ul>
</div>