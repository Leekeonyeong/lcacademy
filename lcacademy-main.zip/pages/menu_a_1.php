<?php
/* www/pages/menu_a_1.php */
include_once('../common.php');

// 페이지 제목
$g5['title'] = "핵심가치/미션/비전";

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.G5_CSS_URL.'/sub.css">', 0);

include_once(G5_PATH.'/head.php');
?>

<h3 style="font-size:1.5rem; font-weight:bold; margin-bottom:30px;">핵심가치/미션/비전</h3>
<hr>
<div class="text-center mb-5">
    <h4 class="text-center mb-5">
        with<br>
        <b style="font-size:1.2em;"><span style="color:#2173ad">생애</span><span style="color:#d11053">진로</span>학교</b>
    </h4>
    <dl class="mb-4 mt-4">
        <dt class="mb-2">
            <span style="padding:5px; background-color:#ece0ec; border-radius:10px; line-height:1.8em">
                <b style="font-size:1.1em">핵심가치</b>
            </span>
        </dt>
        <dd>
            <span style="color:#fb0100">균형</span> 
            <span style="color:#5b7f39">행복</span> 
            <span style="color:#10b058">성장</span> 
            <span style="color:#0070cb">통찰</span> 
            <span style="color:#7a4ba9">협력</span> 
        </dd>
    </dl>
    <dl class="mb-4">
        <dt class="mb-2">
            <span style="padding:5px; background-color:#ece0ec; border-radius:10px; line-height:1.8em">
                <b style="font-size:1.1em">미션</b>
            </span>
        </dt>
        <dd>
            개인과 조직의 성장을 촉진하고 삶의 균형과 행복을 추구하는 기업
        </dd>
    </dl>
    <dl class="mb-4">
        <dt class="mb-2">
            <span style="padding:5px; background-color:#ece0ec; border-radius:10px; line-height:1.8em">
                <b style="font-size:1.1em">비전</b>
            </span>
        </dt>
        <dd>
            통찰과 협력을 통하여 고객의 성장과 행복을 지원하는 생애설계와 진로 플랫폼
        </dd>
    </dl>
</div>
<div class="text-center mb-5 mt-4">
    <dl class="mb-4">
        <dt class="mb-5">
            <span style="padding:5px; background-color:#ece0ec; border-radius:10px; line-height:1.8em">
            <b style="font-size:1.2em;"><span style="color:#2173ad">생애</span><span style="color:#d11053">진로</span>학교 HISTORY</b>
            </span>
        </dt>
        <dd>
            <img src="images/history.jpg" alt="" style="width:100%; max-width:589px;">
            <p class="sound_only">
                시니어 : 생애설계 강의 및 코칭<br>
                부모 : 부모교육/감정코칭, 진로진학, 미래인재교육, 맘코치 양성교육<br>
                유아동, 청소년 : 독서/역사 논술, 자기주도학습 코칭, 진로/인성/리더십<br>
                교사 : 자기주도학습코치, 진로/감정 코치, 각종 진단도구, 해석연수<br>
                청년 : 진로소양교육, 취업역량강화교육, 미래인재역량교육, 재취업역량강화교육<br>
                중장년 : 재취업교육, 전직역량교육, 생애설계교육, 상담사역량강화<br>
                시니어 : 생애설계 강의 및 코칭
            </p>
        </dd>
    </dl>
</div>

<?php
include_once(G5_PATH.'/tail.php');
?>