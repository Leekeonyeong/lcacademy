
<div class="aside_snb">
    <p class="title"><a href="http://thisiszero.dothome.co.kr/pages/menu_b_1.php">프로그램</a></p>
    <ul>
        <li><a href="http://thisiszero.dothome.co.kr/pages/menu_b_1.php">프로그램 소개</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=qualification">자격과정</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=non_qualification">비자격과정</a></li>
        <li><a href="http://thisiszero.dothome.co.kr/bbs/board.php?bo_table=schooling">학교교육</a></li>
    </ul>
</div>